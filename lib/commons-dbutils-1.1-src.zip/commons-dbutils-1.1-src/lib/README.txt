
If building under JDK 1.3, copy the JDBC 2.0 Optional Package (jdbc2_0-stdext.jar) 
from http://java.sun.com/products/jdbc/download.html and place it in this directory. 
